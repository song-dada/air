// import * as d3 from 'd3';

function Line (  ) {
    return(
        <>
            그래프 영역
        </>
    )
}

export default  Line;