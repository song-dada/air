function Footer() {
    return(
        <div className="footer">
            이 화면은 포트폴리오 화면입니다.
        </div>
    );
}

export default Footer;