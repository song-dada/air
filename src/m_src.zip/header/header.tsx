import './header.scss'
// hyomin

function Header() {
    return(
        <header>
            <a href='/' className='titleHeader'>
                 <h1>Weather Air Quality</h1>
            </a>
        </header>
    )
}

export default Header